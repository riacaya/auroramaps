@echo off
title Pemasang Ekstensi AuroraMaps
cd /d "%~dp0"
echo ============================================
echo   PEMASANG EKSTENSI AURORAMAPS - BHUMI
echo ============================================
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Pasang-Ekstensi.ps1" %*
if errorlevel 1 (
    echo.
    echo [GAGAL] Pemasangan tidak selesai. Baca pesan di atas.
    echo.
    pause
    exit /b 1
)
echo.
pause
