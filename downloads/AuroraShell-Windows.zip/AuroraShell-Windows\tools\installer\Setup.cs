// =====================================================
// AuroraMaps Setup - pemasang Windows (setup.exe)
// =====================================================
// Dijalankan dengan dobel-klik dari folder windows-app:
//   1. Menyalin seluruh isi folder aplikasi ke folder pemasangan
//      (default %LOCALAPPDATA%\Programs\AuroraMaps - tanpa admin)
//   2. Mengompilasi AuroraShell.exe (cangkang tanpa Node) dari
//      tools\shell\AuroraShell.cs memakai csc.exe bawaan Windows
//   3. Membuat pintasan Start Menu dan Desktop
//   4. Menawarkan langsung menjalankan aplikasi
//
// Pilihan:
//   setup.exe                    pasang ke folder pengguna
//   setup.exe --program-files    pasang ke %ProgramFiles%\AuroraMaps (butuh admin)
//   setup.exe --ke "D:\Aurora"   pasang ke folder pilihan
//   setup.exe --tanpa-jalankan   jangan langsung dijalankan
//   setup.exe --tanpa-pintasan   jangan membuat pintasan
//   setup.exe --kering           cetak rencana tanpa mengubah apa pun
//   setup.exe --bantu            tampilkan bantuan
//
// Syarat: runtime Microsoft Edge WebView2 (bawaan Windows 10/11).
// Ditulis dalam C# 5 agar bisa dikompilasi csc.exe bawaan Windows.
// =====================================================
using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;

namespace AuroraSetup
{
    class Program
    {
        static string Src;
        static string Dst;
        static bool Langsung = true;
        static bool Pintasan = true;
        static bool Kering = false;

        // Berkas yang TIDAK ikut disalin ke folder pemasangan.
        static readonly string[] SkipFile = {
            "setup.bat", "setup.exe", "BACA-DULU.txt", "Setup.cs"
        };
        // Folder yang TIDAK ikut (paket-SDK sementara milik build-shell.ps1).
        static readonly string[] SkipDir = { "shell-libs" };

        static int Main(string[] args)
        {
            try { Console.Title = "AuroraMaps Setup"; } catch { /* tanpa konsol */ }

            Src = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) ?? ".";
            Dst = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Programs", "AuroraMaps");

            if (!BacaArgumen(args)) return 1;

            Tulis("");
            Tulis("  AuroraMaps - pemasangan ke Windows");
            Tulis("  Sumber : " + Src);
            Tulis("  Tujuan : " + Dst);
            Tulis("");

            if (Kering)
            {
                Tulis("  [kering] mode --kering: tidak ada yang diubah.");
                Tulis("  [kering] sumber shell    : " + (File.Exists(Path.Combine(Src, "tools", "shell", "AuroraShell.cs")) ? "ya" : "TIDAK"));
                Tulis("  [kering] folder tujuan   : " + (Directory.Exists(Dst) ? "sudah ada" : "akan dibuat"));
                Tulis("  [kering] csc.exe         : " + (CariCsc() ?? "TIDAK ADA"));
                Tulis("");
                return 0;
            }

            if (Environment.OSVersion.Platform != PlatformID.Win32NT)
            {
                Gagal("Pemasang ini hanya untuk Windows.");
                return 1;
            }

            // 0) Syarat ------------------------------------------------------
            string csc = CariCsc();
            if (csc == null)
            {
                Gagal("compiler bawaan Windows (csc.exe) tidak ditemukan.\n" +
                      "        Pasang .NET Framework 4.x dari https://dotnet.microsoft.com/download");
                return 1;
            }
            if (!File.Exists(Path.Combine(Src, "tools", "shell", "AuroraShell.cs")))
            {
                Gagal("tools\\shell\\AuroraShell.cs tidak ada di folder ini.\n" +
                      "        setup.exe harus berada bersama isi aplikasi.");
                return 1;
            }

            // AuroraShell/AuroraMaps yang sedang berjalan menahan berkas exe-nya.
            Process[] jalan = Process.GetProcessesByName("AuroraShell");
            if (jalan.Length == 0) jalan = Process.GetProcessesByName("AuroraMaps");
            if (jalan.Length > 0)
            {
                Tulis("  AuroraMaps sedang berjalan.");
                Tulis("  Tutup dulu jendela aplikasinya, lalu jalankan ulang setup.");
                Tulis("");
                Console.Write("   Tetap lanjut? (y/tidak): ");
                string jawab = Console.ReadLine();
                if (jawab == null || jawab.Trim().ToLower() != "y")
                {
                    Tulis("   Dibatalkan.");
                    return 1;
                }
                Tulis("");
            }

            // 1) Folder tujuan ------------------------------------------------
            try
            {
                if (!Directory.Exists(Dst)) Directory.CreateDirectory(Dst);
            }
            catch (Exception e)
            {
                Gagal("tidak bisa membuat folder tujuan: " + e.Message + "\n" +
                      "        Untuk %ProgramFiles% diperlukan hak administrator.");
                return 1;
            }

            // 2) Salin berkas -------------------------------------------------
            Tulis("   [1/3] Menyalin berkas aplikasi...");
            long bytes = 0;
            int files = 0;
            if (Path.GetFullPath(Src).TrimEnd('\\')
                    .Equals(Path.GetFullPath(Dst).TrimEnd('\\'), StringComparison.OrdinalIgnoreCase))
            {
                Tulis("         Folder tujuan = folder sumber - penyalinan dilewati.");
            }
            else
            {
                try
                {
                    Salin(Src, Dst, ref bytes, ref files);
                    Tulis("         " + files + " berkas, " + Mb(bytes) + " MB - selesai.");
                }
                catch (Exception e)
                {
                    Gagal("penyalinan gagal: " + e.Message);
                    return 1;
                }
            }

            // 3) Kompilasi AuroraShell.exe (satu-satunya cangkang) ------------
            Tulis("   [2/3] Mengompilasi AuroraShell.exe (cangkang tanpa Node)...");
            if (!KompilasiShell(csc))
            {
                Gagal("AuroraShell.exe gagal dikompilasi. Jalankan sekali:\n" +
                      "        tools\\shell\\build-shell.ps1");
                return 1;
            }
            Tulis("");

            // 4) Pintasan ------------------------------------------------------
            if (Pintasan)
            {
                Tulis("   [3/3] Membuat pintasan Start Menu dan Desktop...");
                string err = BuatPintasan();
                if (err != null)
                    Tulis("   Peringatan: pintasan gagal (" + err + "). Aplikasi tetap bisa");
                else
                    Tulis("         Pintasan dibuat.");
                if (err != null)
                    Tulis("         dibuka dari: " + Path.Combine(Dst, "AuroraShell.exe"));
            }

            Tulis("");
            Tulis("   Pemasangan selesai.");
            Tulis("     Aplikasi  : " + Dst);
            Tulis("     Cara buka : pintasan \"AuroraMaps\" (Desktop / Start Menu)");
            Tulis("     Shell     : AuroraShell.exe — tanpa Node.js, cangkang GitHub Pages");
            Tulis("                 + pendamping BHUMI + sidecar 8322.");
            Tulis("                 Login BHUMI sekali: \"AuroraShell.exe --show\"");
            Tulis("     Berhenti  : tutup jendela aplikasi");
            Tulis("     Copot     : hapus folder di atas + pintasannya");
            Tulis("");

            if (Langsung)
            {
                Console.Write("   Jalankan AuroraMaps sekarang? [Y/N] ");
                string jawab = Console.ReadLine();
                if (jawab != null && jawab.Trim().StartsWith("Y", StringComparison.OrdinalIgnoreCase))
                {
                    try
                    {
                        Process.Start(Path.Combine(Dst, "AuroraShell.exe"));
                    }
                    catch (Exception e)
                    {
                        Tulis("   Gagal menjalankan: " + e.Message);
                    }
                }
            }
            Tulis("");
            return 0;
        }

        // ── Pilihan baris perintah ───────────────────────────────────────────
        static bool BacaArgumen(string[] args)
        {
            for (int i = 0; i < args.Length; i++)
            {
                string a = args[i];
                if (string.Equals(a, "--program-files", StringComparison.OrdinalIgnoreCase))
                {
                    Dst = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "AuroraMaps");
                }
                else if (string.Equals(a, "--ke", StringComparison.OrdinalIgnoreCase))
                {
                    if (i + 1 >= args.Length)
                    {
                        Gagal("--ke butuh nama folder, contoh: --ke \"D:\\AuroraMaps\"");
                        return false;
                    }
                    i++;
                    Dst = args[i];
                }
                else if (string.Equals(a, "--tanpa-jalankan", StringComparison.OrdinalIgnoreCase)) Langsung = false;
                else if (string.Equals(a, "--tanpa-pintasan", StringComparison.OrdinalIgnoreCase)) Pintasan = false;
                else if (string.Equals(a, "--kering", StringComparison.OrdinalIgnoreCase)) Kering = true;
                else if (a == "/?" || string.Equals(a, "--bantu", StringComparison.OrdinalIgnoreCase) ||
                         string.Equals(a, "--help", StringComparison.OrdinalIgnoreCase))
                {
                    Tulis("AuroraMaps Setup");
                    Tulis("  setup.exe                    pasang ke folder pengguna");
                    Tulis("  setup.exe --program-files    pasang ke Program Files (butuh admin)");
                    Tulis("  setup.exe --ke \"D:\\Folder\"   pasang ke folder pilihan");
                    Tulis("  setup.exe --tanpa-jalankan   jangan langsung dijalankan");
                    Tulis("  setup.exe --tanpa-pintasan   jangan membuat pintasan");
                    Tulis("  setup.exe --kering           cetak rencana, tidak mengubah apa pun");
                    return false;
                }
                else
                {
                    Gagal("pilihan tidak dikenal: " + a + "  (gunakan --bantu)");
                    return false;
                }
            }
            return true;
        }

        // ── Penyalinan rekursif ──────────────────────────────────────────────
        static void Salin(string from, string to, ref long bytes, ref int files)
        {
            foreach (string f in Directory.GetFiles(from))
            {
                string nama = Path.GetFileName(f);
                if (Array.IndexOf(SkipFile, nama) >= 0) continue;
                if (nama.EndsWith(".log", StringComparison.OrdinalIgnoreCase)) continue;
                if (nama.EndsWith(".zip", StringComparison.OrdinalIgnoreCase)) continue;
                File.Copy(f, Path.Combine(to, nama), true);
                files++;
                bytes += new FileInfo(f).Length;
            }
            foreach (string d in Directory.GetDirectories(from))
            {
                string nama = Path.GetFileName(d);
                if (Array.IndexOf(SkipDir, nama) >= 0) continue;
                string tujuan = Path.Combine(to, nama);
                if (!Directory.Exists(tujuan)) Directory.CreateDirectory(tujuan);
                Salin(d, tujuan, ref bytes, ref files);
            }
        }

        // ── Pencari csc.exe ──────────────────────────────────────────────────
        static string CariCsc()
        {
            string[] kandidat = {
                Path.Combine(Environment.GetEnvironmentVariable("WINDIR") ?? @"C:\Windows",
                    @"Microsoft.NET\Framework64\v4.0.30319\csc.exe"),
                Path.Combine(Environment.GetEnvironmentVariable("WINDIR") ?? @"C:\Windows",
                    @"Microsoft.NET\Framework\v4.0.30319\csc.exe")
            };
            foreach (string k in kandidat) if (File.Exists(k)) return k;
            return null;
        }

        // ── Kompilasi shell tanpa-Node (cangkang GitHub Pages + sidecar;
        //    port SidecarServer.kt/BhumiBridge.kt) — upaya terbaik ───────────
        static bool KompilasiShell(string csc)
        {
            try
            {
                string cs = Path.Combine(Dst, "tools", "shell", "AuroraShell.cs");
                string core = Path.Combine(Dst, "Microsoft.Web.WebView2.Core.dll");
                string form = Path.Combine(Dst, "Microsoft.Web.WebView2.WinForms.dll");
                if (!File.Exists(cs)) return false;
                if (!File.Exists(core) || !File.Exists(form))
                {
                    Tulis("   Info: DLL WebView2 belum ada di root (shell belum di-build).");
                    Tulis("         Jalankan sekali: tools\\shell\\build-shell.ps1");
                    return false;
                }
                string ico = Path.Combine(Dst, "tools", "installer", "auroramaps.ico");
                string ops = File.Exists(ico) ? " /win32icon:\"" + ico + "\"" : "";
                string keluar = "";
                int rc = Jalankan(csc,
                    "/nologo /target:winexe /platform:anycpu" + ops +
                    " /out:\"" + Path.Combine(Dst, "AuroraShell.exe") + "\"" +
                    " /r:System.dll /r:System.Core.dll /r:System.Drawing.dll" +
                    " /r:System.Windows.Forms.dll" +
                    " /r:\"" + core + "\" /r:\"" + form + "\"" +
                    " \"" + cs + "\"", out keluar);
                if (rc != 0)
                {
                    Tulis("   Peringatan: kompilasi AuroraShell.exe gagal:");
                    Tulis("   " + keluar.Trim());
                    return false;
                }
                Tulis("         " + Path.Combine(Dst, "AuroraShell.exe"));
                return true;
            }
            catch
            {
                return false;
            }
        }

        // ── Pintasan lewat WScript.Shell (COM, bawaan Windows) ───────────────
        static string BuatPintasan()
        {
            try
            {
                // Pintasan selalu menunjuk cangkang tanpa Node.
                string exe = Path.Combine(Dst, "AuroraShell.exe");
                string sm = Environment.GetFolderPath(Environment.SpecialFolder.StartMenu);
                string dk = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                string[] target = {
                    Path.Combine(sm, "Programs", "AuroraMaps.lnk"),
                    Path.Combine(dk, "AuroraMaps.lnk")
                };
                Type t = Type.GetTypeFromProgID("WScript.Shell");
                if (t == null) return "WScript.Shell tidak tersedia";
                object shell = Activator.CreateInstance(t);
                foreach (string lnk in target)
                {
                    object s = t.InvokeMember("CreateShortcut", BindingFlags.InvokeMethod, null, shell, new object[] { lnk });
                    Type st = s.GetType();
                    st.InvokeMember("TargetPath", BindingFlags.SetProperty, null, s, new object[] { exe });
                    st.InvokeMember("WorkingDirectory", BindingFlags.SetProperty, null, s, new object[] { Dst });
                    st.InvokeMember("WindowStyle", BindingFlags.SetProperty, null, s, new object[] { 7 });
                    st.InvokeMember("Description", BindingFlags.SetProperty, null, s, new object[] { "AuroraMaps - GIS Viewer" });
                    st.InvokeMember("Save", BindingFlags.InvokeMethod, null, s, null);
                }
                return null;
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        // ── Bantuan ──────────────────────────────────────────────────────────
        static int Jalankan(string exe, string argumen, out string keluar)
        {
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo(exe, argumen);
                psi.UseShellExecute = false;
                psi.RedirectStandardOutput = true;
                psi.RedirectStandardError = true;
                psi.CreateNoWindow = true;
                using (Process p = Process.Start(psi))
                {
                    string o = p.StandardOutput.ReadToEnd();
                    string e = p.StandardError.ReadToEnd();
                    p.WaitForExit();
                    keluar = o + e;
                    return p.ExitCode;
                }
            }
            catch (Exception ex)
            {
                keluar = ex.Message;
                return 1;
            }
        }

        static string Mb(long b) { return (b / 1048576.0).ToString("0.0"); }
        static void Tulis(string s) { Console.WriteLine(s); }
        static void Gagal(string s)
        {
            Console.WriteLine("");
            Console.WriteLine("  GAGAL: " + s);
            Console.WriteLine("");
        }
    }
}
