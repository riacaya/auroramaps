# =====================================================
# test-sidecar.ps1 — uji endpoint sidecar 8322 (shell ATAU node)
# =====================================================
# Jalankan:
#   powershell -ExecutionPolicy Bypass -File tools\shell\test-sidecar.ps1
# Menyatukan Invoke-RestMethod supaya bebas dari drama kutipan cURL.
# =====================================================
$Base = 'http://127.0.0.1:8322'
$Hdr  = @{ 'origin' = 'https://riacaya.github.io' }

function Uji([string]$Nama, [scriptblock]$Aksi) {
    try {
        $r = & $Aksi
        $json = $r | ConvertTo-Json -Compress -Depth 4
        Write-Output ("{0,-12} OK   {1}" -f $Nama, (if2 ($json.Length) $json))
    } catch {
        $m = $_.Exception.Message
        if ($_.Exception.Response) { $m = ('HTTP ' + [int]$_.Exception.Response.StatusCode) }
        Write-Output ("{0,-12} FAIL {1}" -f $Nama, $m)
    }
}
function if2($a, $b) { if ($a -gt 140) { $b.Substring(0, 140) + ' ...' } else { $b } }

# Endpoint legal tapi HARUS membalas 403 (whitelist menolak) — kalau memang
# 403, ini PASS bukan FAIL.
function Invoke-Ilegal([string]$Uri, [string]$Body, [int]$Harusnya) {
    try {
        Invoke-RestMethod -Uri $Uri -Method Post -Headers $Hdr -ContentType 'application/json' -Body $Body -TimeoutSec 15 | Out-Null
        throw "seharusnya $Harusnya, dapat 200"
    } catch {
        $st = 999
        if ($_.Exception.Response) { $st = [int]$_.Exception.Response.StatusCode }
        if ($st -eq $Harusnya) { return "whitelist menolak (HTTP $st) sesuai harapan" }
        throw "seharusnya $Harusnya, dapat $st"
    }
}

# Endpoint melewati whitelist, memanggil API DI DALAM halaman BHUMI, dan
# galat itu harus PENUH sasaran (pertandingan substring) → 502 {error}.
function CobaError([string]$Uri, [string]$Body, [string]$Harus, [int]$Tunggu) {
    # HttpWebRequest supaya kompatibel Windows PowerShell 5.1 (tanpa
    # Invoke-WebRequest -SkipHttpErrorCheck yang baru ada di PS 7)
    $req = [Net.HttpWebRequest]::Create($Uri)
    $req.Method = 'POST'
    $req.ContentType = 'application/json'
    $req.Timeout = $Tunggu * 1000
    $req.Headers.Add('origin', 'https://riacaya.github.io')
    $bodyBytes = [Text.Encoding]::UTF8.GetBytes($Body)
    $st = $req.GetRequestStream()
    $st.Write($bodyBytes, 0, $bodyBytes.Length); $st.Close()
    $isi = ''; $kode = 0
    try { $resp = $req.GetResponse(); $kode = [int]$resp.StatusCode; $sr = New-Object IO.StreamReader($resp.GetResponseStream()); $isi = $sr.ReadToEnd() }
    catch [Net.WebException] {
        $r2 = $_.Exception.Response
        if ($r2 -eq $null) { throw $_ }
        $kode = [int]$r2.StatusCode
        $sr = New-Object IO.StreamReader($r2.GetResponseStream()); $isi = $sr.ReadToEnd()
    }
    if ($kode -eq 502 -and $isi -match $Harus) {
        return ('galat halaman dibawa ke 502: ' + $isi.Substring(0, [Math]::Min(90, $isi.Length)))
    }
    throw ('harap 502+' + $Harus + ', dapat HTTP ' + $kode + ': ' + $isi.Substring(0, [Math]::Min(140, $isi.Length)))
}

Uji 'status'  { Invoke-RestMethod -Uri "$Base/status"  -Headers $Hdr -TimeoutSec 12 }
Uji 'batas'   { Invoke-RestMethod -Uri "$Base/batas"   -Method Post -Headers $Hdr -ContentType 'application/json' -Body '{"url":"https://bhumi.atrbpn.go.id/api/propinsi"}' -TimeoutSec 30 }Uji 'search-' { Invoke-Ilegal "$Base/search"  '{"path":"/expapi/evil","body":{}}' 403 }
Uji 'tile-'   { Invoke-Ilegal "$Base/tile"   '{"url":"https://evil.example/t.png"}' 403 }
Uji 'search+' { Invoke-RestMethod -Uri "$Base/search"  -Method Post -Headers $Hdr -ContentType 'application/json' -Body '{"path":"/expapi/getBidang","body":{}}' -TimeoutSec 42 }
# identify: body nyokin latlon saja TIDAK sempurna untuk inject (harus ada
# x/y/bbox dari klik peta) → galat "Parameter koordinat tidak valid." dari
# DALAM halaman BHUMI, dinormalkan jadi 502 — itu PASS=false bukan shell-
# mati; sebaliknya membuktikan relai sampai API halaman & turunan galat.
Uji 'identify' { CobaError "$Base/identify" '{"body":{"latitude":-6.2,"longitude":106.8}}' 'Parameter koordinat' 52 }
