using System;
using System.IO;
using System.Linq;

class Check
{
    static int Main()
    {
        string root = @"D:\AuroraMaps\windows-app";
        var files = Directory.EnumerateFiles(root, "*.*", SearchOption.AllDirectories)
            .Where(f => !Path.GetFileName(f).StartsWith(".") && !f.Contains("\\runtimes\\") && !f.Contains("\\tools\\"))
            .OrderBy(f => f);
        foreach (var f in files)
        {
            Console.WriteLine(f);
        }
        return 0;
    }
}
