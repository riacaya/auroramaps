# =====================================================
# build-shell.ps1 - siapkan SDK WebView2 + kompilasi
# tools\shell\AuroraShell.cs -> AuroraShell.exe (TANPA NODE).
# =====================================================
# Jalankan SEKALI di PC yang terhubung internet (atau kapan saja
# untuk kompilasi ulang - SDK tidak diunduh lagi bila sudah ada):
#   powershell -ExecutionPolicy Bypass -File tools\shell\build-shell.ps1
# Opsi:
#   -VersiSdk 1.0.2903.40   versi paket NuGet Microsoft.Web.WebView2
#   -LewatiUnduh            jangan unduh (gagal bila DLL belum ada)
#   -SimpanPaket            simpan paket NuGet di shell-libs (cache offline)
#
# Hasil di root windows-app (folder aplikasi):
#   AuroraShell.exe
#   Microsoft.Web.WebView2.Core.dll + Microsoft.Web.WebView2.WinForms.dll
#   runtimes\win-{x86,x64,arm64}\native\WebView2Loader.dll
# Semuanya ikut tersalin oleh setup.exe ke folder pemasangan.
#
# Catatan: paket NuGet hanya dipakai untuk MENGAMBIL berkas di atas, lalu
# dibuang (kecuali -SimpanPaket). Microsoft.Web.WebView2.Wpf.dll dan folder
# runtimes\win-*\native_uap tidak dipakai cangkang WinForms -> tidak disalin,
# supaya paket tetap ringan (~1,4 MB, bukan ~56 MB).
# =====================================================
param(
    [string]$VersiSdk = "1.0.2903.40",
    [switch]$LewatiUnduh,
    [switch]$SimpanPaket
)

$ErrorActionPreference = "Stop"
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}

$RootDir = $PSScriptRoot
$CacheDir = Join-Path $RootDir "shell-libs"
# RootDir = <app>\tools\shell -> AppRoot = <app> (parent dari parent)
$AppRoot = Split-Path -Parent (Split-Path -Parent $RootDir)
$FileCs  = Join-Path $RootDir "AuroraShell.cs"
$FileIco = Join-Path $AppRoot "tools\installer\auroramaps.ico"
$OutExe  = Join-Path $AppRoot "AuroraShell.exe"

# Hanya assembly yang benar-benar dirujuk AuroraShell.cs (WinForms, tanpa WPF).
$DllPerlu = @("Microsoft.Web.WebView2.Core.dll", "Microsoft.Web.WebView2.WinForms.dll")
$Arsitektur = @("win-x86", "win-x64", "win-arm64")

Write-Host ""
Write-Host "  AuroraShell build (cangkang tanpa Node)"
Write-Host "  SDK  : Microsoft.Web.WebView2 $VersiSdk"
Write-Host "  skrip: $FileCs"
Write-Host ""

# ── 1) csc.exe bawaan Windows (tanpa Visual Studio) ─────────────
$Csc = @(
    (Join-Path $env:WINDIR "Microsoft.NET\Framework64\v4.0.30319\csc.exe"),
    (Join-Path $env:WINDIR "Microsoft.NET\Framework\v4.0.30319\csc.exe")
) | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $Csc) { throw "csc.exe tidak ditemukan - pasang .NET Framework 4.x." }
Write-Host "  [1/3] csc       : $Csc"

# ── 2) SDK WebView2: pakai yang sudah ada, unduh hanya bila kurang ──
function SdkKurang {
    foreach ($n in $DllPerlu) {
        if (-not (Test-Path (Join-Path $AppRoot $n))) { return $true }
    }
    foreach ($a in $Arsitektur) {
        if (-not (Test-Path (Join-Path $AppRoot ("runtimes\$a\native\WebView2Loader.dll")))) { return $true }
    }
    return $false
}

if (-not (SdkKurang)) {
    Write-Host "  [2/3] SDK       : sudah ada di root - unduhan dilewati"
} else {
    if ($LewatiUnduh) {
        throw "DLL WebView2 belum lengkap di root dan -LewatiUnduh dipakai. Jalankan tanpa -LewatiUnduh."
    }
    $NamaPaket = "microsoft.web.webview2.$VersiSdk.nupkg"
    $Url       = "https://api.nuget.org/v3-flatcontainer/microsoft.web.webview2/$VersiSdk/$NamaPaket"
    $Isi       = Join-Path $CacheDir ("paket-" + $VersiSdk)
    $Nupkg     = Join-Path $CacheDir $NamaPaket
    if (-not (Test-Path $CacheDir)) { New-Item -ItemType Directory -Path $CacheDir -Force | Out-Null }
    if (-not (Test-Path $Nupkg)) {
        Write-Host "  [2/3] unduh     : $Url"
        Invoke-WebRequest -Uri $Url -OutFile $Nupkg -UseBasicParsing
    }
    if (Test-Path $Isi) { Remove-Item $Isi -Recurse -Force }
    Copy-Item $Nupkg (Join-Path $CacheDir "kopi.zip") -Force
    Expand-Archive (Join-Path $CacheDir "kopi.zip") $Isi -Force
    Remove-Item (Join-Path $CacheDir "kopi.zip") -Force

    # Salin HANYA yang dipakai: Core + WinForms, dan loader native per arsitektur.
    foreach ($n in $DllPerlu) {
        Copy-Item (Join-Path $Isi ("lib\net462\" + $n)) (Join-Path $AppRoot $n) -Force
    }
    foreach ($a in $Arsitektur) {
        $tujuan = Join-Path $AppRoot ("runtimes\$a\native")
        if (-not (Test-Path $tujuan)) { New-Item -ItemType Directory -Path $tujuan -Force | Out-Null }
        Copy-Item (Join-Path $Isi ("runtimes\$a\native\WebView2Loader.dll")) (Join-Path $tujuan "WebView2Loader.dll") -Force
    }

    if ($SimpanPaket) {
        Write-Host "  [2/3] paket     : disimpan di $CacheDir (-SimpanPaket)"
    } else {
        Remove-Item $Isi -Recurse -Force
        Remove-Item $Nupkg -Force
        if ((Get-ChildItem $CacheDir -Force | Measure-Object).Count -eq 0) { Remove-Item $CacheDir -Force }
        Write-Host "  [2/3] paket     : diambil lalu dibuang (pakai -SimpanPaket untuk cache offline)"
    }
}

# Bersihkan sisa lama: WPF (tidak dipakai) + proyeksi UWP native_uap.
Remove-Item (Join-Path $AppRoot "Microsoft.Web.WebView2.Wpf.dll") -Force -ErrorAction SilentlyContinue
foreach ($a in $Arsitektur) {
    Remove-Item (Join-Path $AppRoot ("runtimes\$a\native_uap")) -Recurse -Force -ErrorAction SilentlyContinue
}

# ── 3) Kompilasi (lewat response file - aman utk path spasi/kutip) ──
# AuroraShell yang berjalan memegang exe-nya -> hentikan dulu (fail-safe).
Get-Process -Name AuroraShell -ErrorAction SilentlyContinue |
    ForEach-Object { Write-Host "  -- AuroraShell berjalan dihentikan (PID $($_.Id))"; $_.Kill() }
Start-Sleep -Seconds 2

$Rsp = New-Object System.Collections.Generic.List[string]
$Rsp.Add("/nologo")
$Rsp.Add("/target:winexe")
$Rsp.Add("/platform:anycpu")
$Rsp.Add("/optimize+")
$Rsp.Add('/out:"' + $OutExe + '"')
if (Test-Path $FileIco) { $Rsp.Add('/win32icon:"' + $FileIco + '"'); }
$Rsp.Add("/r:System.dll"); $Rsp.Add("/r:System.Core.dll")
$Rsp.Add("/r:System.Drawing.dll"); $Rsp.Add("/r:System.Windows.Forms.dll")
foreach ($n in $DllPerlu) { $Rsp.Add('/r:"' + (Join-Path $AppRoot $n) + '"') }
$Rsp.Add('"' + $FileCs + '"')
$RspFile = Join-Path $env:TEMP "auroramaps-csc.rsp"
Set-Content -Path $RspFile -Value $Rsp -Encoding Unicode
Write-Host "  [3/3] kompilasi -> AuroraShell.exe ..."
& $Csc ("@" + $RspFile)
$kode = $LASTEXITCODE
Remove-Item $RspFile -Force -ErrorAction SilentlyContinue
if ($kode -ne 0) { throw "Kompilasi gagal (csc exit=$kode) - cek pesan di atas." }
if (-not (Test-Path $OutExe)) { throw "Kompilasi gagal - cek pesan di atas." }

Write-Host ""
Write-Host "  OK = $OutExe"
Write-Host "  Dobel-klik AuroraShell.exe (tanpa Node.js):"
Write-Host "    cangkang   : GitHub Pages (WebView2 #1)"
Write-Host "    pendamping : bhumi tersembunyi (WebView2 #2) + sidecar 8322"
Write-Host "  login BHUMI sekali manual:"
Write-Host "    AuroraShell.exe --show"
