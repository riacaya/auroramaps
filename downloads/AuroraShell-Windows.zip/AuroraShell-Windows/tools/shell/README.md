# AuroraShell — cangkang Windows TANPA Node.js

Versi Windows dari pola aplikasi Android (`android-app`): satu EXE berisi
cangkang WebView2 + pendamping BHUMI + server relai 8322. Ditulis C# 5 —
dikompilasi `csc.exe` bawaan Windows, tanpa Node, tanpa browser eksternal
(tidak ada lagi CDP Edge/Chrome headless).

## Arsitektur (port dari APK)

| Berkas sumber (APK)              | Tunjungan di sini                  |
|----------------------------------|------------------------------------|
| `MainActivity.kt`                | `MainForm` (cangkang GitHub Pages) |
| `SidecarServer.kt` (TcpListener) | `SidecarHttpServer` (TcpListener 127.0.0.1:8322) |
| `BhumiBridge.kt` (WebView #2)    | `BhumiSidecar` (WebView2 #2 off-screen) |

Kontrak dijaga sama persis dengan sidecar PC lama → `src/js/bhumiSidecar.js`
berjalan tanpa perubahan: rute `/status /search /identify /analisa /tile
/gfi /proxy /proxy-image /batas /token-sync`, whitelist, batas body 512 KB,
balasan galat HTTP 502 `{error}`.

## Build (butuh internet hanya saat SDK belum ada)

```
powershell -ExecutionPolicy Bypass -File tools\shell\build-shell.ps1
```

Bila DLL WebView2 belum ada di root `windows-app`, skrip mengunduh paket NuGet
`Microsoft.Web.WebView2` (SDK 1.0.2903.40), menyalin yang **dipakai saja** —
`Microsoft.Web.WebView2.Core.dll`, `Microsoft.Web.WebView2.WinForms.dll`, dan
`runtimes\win-{x86,x64,arm64}\native\WebView2Loader.dll` — lalu membuang paketnya
(opsi `-SimpanPaket` untuk cache offline). Setelah itu kompilasi tiap kali hanya
lewat `csc.exe`, tanpa unduhan. Opsi lain: `-VersiSdk`, `-LewatiUnduh`.

`Microsoft.Web.WebView2.Wpf.dll` dan `runtimes\win-*\native_uap` **tidak**
dipakai cangkang WinForms → tidak disalin; paket tetap ~1,4 MB.

## Prasyarat

**Microsoft Edge WebView2 Runtime** — sudah terpasang bawaan Windows 11 dan
sebagian besar Windows 10 (via Edge Evergreen). Bila tidak ada, AuroraShell
menampilkan tautan unduhan:
<https://developer.microsoft.com/microsoft-edge/webview2/>

## Pemakaian

- `AuroraShell.exe` — dobel-klik (pintasan Setup memakai ini bila ada).
- `AuroraShell.exe --show` (alias `--jendela` / `login`) — tampilkan jendela
  pendamping BHUMI untuk login manual sekali; sesi tersimpan otomatis di
  `%LOCALAPPDATA%\AuroraMaps\Bhumi` (menggantikan `.chrome-bhumi-profile`).
- `AuroraShell.exe --app-url <url>` — ganti alamat cangkang (uji lokal).
- Log: `%LOCALAPPDATA%\AuroraMaps\auroramaps-shell.log`.

## Catatan perkembangan

- Penjagaan sesi port 1:1 dari `BhumiBridge.kt`: probe 5 dtk (kalau script
  hilang → suntik ulang, dua kali gagal → muat ulang) and tick 30 dtk
  (jaga URL `/peta` + token loginApi < 150 dtk → muat ulang preventif).
- `ProcessFailed` (renderer mati/OOM) → kontrol dibangun ulang di tempat,
  panggilan yang tertahan diberi balasan galat — persis `rebuild()` Android.
- Suntikan API: `AddScriptToExecuteOnDocumentCreatedAsync` (WebView2) =
  CDP `Page.addScriptToEvaluateOnNewDocument` + guard idempotent di
  `sidecar-inject.js` (v14, sama dengan APK, timeout fetch 14 dtk).
- CORS: origin `https://riacaya.github.io` + extra dari
  `sidecar-origins.json` di root paket, plus header
  `Access-Control-Allow-Private-Network` untuk preflight PNA dari origin
  publik ke loopback.
- `sidecar-inject.js` dan `sidecar-origins.json` adalah satu-satunya aset
  yang dipakai bersama dengan APK; keduanya ada di root `windows-app` dan
  ikut tersalin oleh `setup.exe`.
- Jalur Node lama (`AuroraMaps.exe`, `local-server.mjs`,
  `tools/bhumi-bridge/`) sudah dihapus — AuroraShell adalah satu-satunya
  cangkang Windows.
