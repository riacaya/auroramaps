// =====================================================
// AuroraShell.exe — CANGKANG WINDOWS TANPA NODE (port APK)
// =====================================================
// Versi Windows dari pola android-app (MainActivity.kt +
// SidecarServer.kt + BhumiBridge.kt), ditulis C# 5 agar
// bisa dikompilasi csc.exe bawaan Windows tanpa Node.js,
// tanpa browser eksternal (CDP), dan tanpa server lokal 8321:
//
//   1. Komponen #1 — cangkang: WebView2 memuat situs
//      GitHub Pages langsung (APK = CANGKANG, Nov 2026).
//   2. Komponen #2 — pendamping BHUMI: WebView2 KEDUA yang
//      tak terlihat memuat https://bhumi.atrbpn.go.id/peta
//      lalu menyuntikkan sidecar-inject.js (berkas yang SAMA
//      dengan APK Android) di setiap dokumen
//      baru — semua fetch ter-stempel Origin/Referer bhumi
//      asli sehingga lolos WAF ATR/BPN.
//   3. Komponen #3 — server relai: TcpListener loopback
//      127.0.0.1:8322, rute/whitelist/bentuk galat disalin
//      1:1 dari SidecarServer.kt supaya src/js/
//      bhumiSidecar.js berjalan tanpa perubahan apa pun.
//
// Alasan tidak lagi memakai Node + CDP:
//   • Tidak ada browser eksternal → masalah port CDP yang
//     jatuh ke excludedportrange Windows (9355 dkk) LENYAP.
//   • Bukan headless → UA tidak memuat "HeadlessChrome",
//     tidak perlu netralisasi UA (WAF 403 semua tile).
//   • Profil sesi = folder userData WebView2 sendiri
//     (%LOCALAPPDATA%\AuroraMaps\Bhumi).
//   • Penjagaan sesi (port BhumiBridge.kt): probeHeal 5 dtk,
//     tick 30 dtk, token < 150 dtk → muat ulang halaman.
//
// Prasyarat: Microsoft Edge WebView2 Runtime (terpasang
// bawaan Windows 11 / sebagian besar Windows 10 karena Edge).
// Kalau tidak ada → pesan jelas dengan tautan unduhan.
//
// Opsi:
//   --show / --jendela / login   tampilkan jendela pendamping
//                                BHUMI sekali untuk login manual
//                                (sesi tersimpan otomatis)
//   --app-url <url>              ganti alamat cangkang (uji)
//
// Log: %LOCALAPPDATA%\AuroraMaps\auroramaps-shell.log
// Kompilasi (lihat build-shell.ps1):
//   csc /nologo /target:winexe /r:Microsoft.Web.WebView2.Core.dll
//       /r:Microsoft.Web.WebView2.WinForms.dll
//       /r:System.Windows.Forms.dll /r:System.Drawing.dll
//       /out:AuroraShell.exe AuroraShell.cs
// =====================================================
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace AuroraShell
{
    internal static class Program
    {
        internal const string AppUrlDefault = "https://riacaya.github.io/auroramaps/app/";
        internal const string BhumiUrl = "https://bhumi.atrbpn.go.id/peta";
        internal const string BhumiOrigin = "https://bhumi.atrbpn.go.id/";

        private static string _logFile = null;

        [STAThread]
        static void Main(string[] args)
        {
            bool showBhumi = false;
            string appUrl = AppUrlDefault;
            for (int i = 0; i < args.Length; i++)
            {
                string a = (args[i] ?? "").ToLowerInvariant();
                if (a == "--show" || a == "--jendela" || a == "login") showBhumi = true;
                else if (a == "--app-url" && i + 1 < args.Length) { i++; appUrl = args[i]; }
            }

            string dataDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "AuroraMaps");
            try { Directory.CreateDirectory(dataDir); } catch { /* abaikan */ }
            _logFile = Path.Combine(dataDir, "auroramaps-shell.log");
            Log("AuroraMaps Shell | " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") +
                " | cangkang: " + appUrl + (showBhumi ? " | jendela BHUMI: tampil" : ""));

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm(appUrl, showBhumi));
        }

        internal static void Log(string s)
        {
            try
            {
                if (_logFile == null) return;
                try
                {
                    var fi = new FileInfo(_logFile);
                    if (fi.Exists && fi.Length > 1024 * 1024) fi.Delete();
                }
                catch { /* abaikan */ }
                File.AppendAllText(_logFile,
                    DateTime.Now.ToString("HH:mm:ss") + "  " + s + "\r\n");
            }
            catch { /* log tidak boleh mengganggu */ }
        }

        internal static string AppDir
        {
            get
            {
                try
                {
                    return Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) ?? ".";
                }
                catch { return "."; }
            }
        }
    }

    // =====================================================
    // MainForm — jendela aplikasi (cangkang) + host pendamping
    // =====================================================
    // Setara MainActivity.kt: WebView utama (cangkang GitHub
    // Pages) Dock=Fill; WebView pendamping BHUMI hidup di
    // SUMBU OFF-SCREEN (-40000,-40000) supaya tetap dirender
    // (timer/fetch tetap jalan) tanpa pernah terlihat — mirip
    // container INVISIBLE milik BhumiBridge.kt. Mode login:
    // pendamping dipindah menutupi seluruh jendela, tombol ✕
    // yang disuntik memanggil kembali HideBhumi().
    internal class MainForm : Form
    {
        private readonly string _appUrl;
        private readonly bool _showBhumi;
        private WebView2 _appWv = null;
        private WebView2 _bhumiWv = null;
        private BhumiSidecar _sidecar = null;
        private SidecarHttpServer _server = null;

        internal MainForm(string appUrl, bool showBhumi)
        {
            _appUrl = appUrl;
            _showBhumi = showBhumi;

            Text = "AuroraMaps";
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new System.Drawing.Size(1240, 780);
            MinimumSize = new System.Drawing.Size(680, 440);
            AutoScaleMode = AutoScaleMode.Font;
            var ico = Path.Combine(Program.AppDir, "tools", "installer", "auroramaps.ico");
            if (File.Exists(ico))
            {
                try { Icon = new System.Drawing.Icon(ico); } catch { /* abaikan */ }
            }

            Shown += (s, e) => StartShell();
            FormClosing += (s, e) => Shutdown();
        }

        // ── Jalankan cangkang + pendamping + server ─────────────────
        private async void StartShell()
        {
            // 1) Cangkang — WebView2 memuat situs GitHub Pages (APK style).
            try
            {
                string shellProfile = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "AuroraMaps", "Shell");
                var envShell = await CoreWebView2Environment.CreateAsync(null, shellProfile, null);
                _appWv = new WebView2();
                _appWv.Dock = DockStyle.Fill;
                Controls.Add(_appWv);
                await _appWv.EnsureCoreWebView2Async(envShell);
                _appWv.Source = new Uri(_appUrl);
                Program.Log("Cangkang siap: " + _appUrl);
            }
            catch (Exception ex)
            {
                // Umumnya: runtime WebView2 tidak terpasang.
                Program.Log("WebView2 gagal: " + ex.Message);
                MessageBox.Show(this,
                    "Runtime Microsoft Edge WebView2 tidak tersedia di PC ini.\n\n" +
                    "Unduh (gratis, beberapa MB):\n" +
                    "    https://developer.microsoft.com/microsoft-edge/webview2/\n" +
                    "  → \"Evergreen Runtime\" (Standalone Installer), pasang sekali,\n" +
                    "    lalu buka AuroraShell.exe lagi.",
                    "AuroraMaps", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Close();
                return;
            }

            // 2) Pendamping BHUMI (WebView2 kedua, tak terlihat) + server 8322.
            _sidecar = new BhumiSidecar(this);
            bool ok = await _sidecar.StartAsync(_showBhumi);
            if (!ok)
            {
                Program.Log("Pendamping BHUMI gagal dimulai (runtime WebView2 / folder profil).");
            }

            _server = new SidecarHttpServer(_sidecar);
            if (!_server.Start())
            {
                Program.Log("Port 8322 tidak bisa dibuka — dicek aplikasi lain.");
                MessageBox.Show(this,
                    "Sidecar 8322 tidak bisa dibuka — cek port dipakai aplikasi lain.",
                    "AuroraMaps", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Shutdown()
        {
            if (_server != null) _server.Stop();
            if (_sidecar != null) _sidecar.Release();
            Program.Log("Aplikasi ditutup.");
            Program.Log("---");
        }

        // ── Tempat tinggal kontrol pendamping (dipanggil bridge) ────
        internal void AttachBhumi(WebView2 wv)
        {
            if (_bhumiWv != null && !ReferenceEquals(_bhumiWv, wv))
            {
                try { Controls.Remove(_bhumiWv); _bhumiWv.Dispose(); } catch { }
            }
            _bhumiWv = wv;
            wv.Size = new System.Drawing.Size(1280, 900);
            wv.Location = new System.Drawing.Point(-40000, -40000); // off-screen, tetap hidup
            Controls.Add(wv);
        }

        internal void DetachBhumi(WebView2 wv)
        {
            try { Controls.Remove(wv); } catch { }
            if (ReferenceEquals(_bhumiWv, wv)) { _bhumiWv = null; }
        }

        internal void ShowBhumi()
        {
            if (_bhumiWv == null) return;
            _bhumiWv.Size = ClientSize;
            _bhumiWv.Location = new System.Drawing.Point(0, 0);
            _bhumiWv.BringToFront();
            Program.Log("Jendela BHUMI tampil (login manual).");
        }

        internal void HideBhumi()
        {
            if (_bhumiWv == null) return;
            _bhumiWv.Location = new System.Drawing.Point(-40000, -40000);
            _appWv.BringToFront();
            Program.Log("Jendela BHUMI disembunyikan.");
        }
    }

    // =====================================================
    // BhumiSidecar — port langsung BhumiBridge.kt
    // =====================================================
    // • WebView2 kedua memuat BHUMI + suntikkan sidecar-inject.js
    //   (AddScriptToEvaluateOnNewDocument = setara CDP
    //   Page.addScriptToEvaluateOnNewDocument, plus probeHeal 5 dtk).
    // • Promise di halaman di-`await` langsung oleh
    //   ExecuteScriptAsync → tidak butuh NativeBridge.deliver
    //   milik Android (Android tidak punya await native).
    // • Kejagaan sesi: tick 30 dtk (jaga URL + token < 150 dtk
    //   → muat ulang; setara tick() Android), probeHeal 5 dtk
    //   (setara reconnect CDP 5 dtk di PC), onRenderProcessGone
    //   → ProcessFailed ● bangun ulang kontrol di tempat.
    internal class BhumiSidecar
    {
        private static readonly string[] Allowed = new string[] {
            "status", "search", "identify", "tile", "gfi",
            "proxy", "proxyImage", "batas", "tokenSync", "analisa"
        };
        private const long MinSisa = 150;          // detik sisa token → segarkan preventif
        private const int ReloadLockMs = 45000;

        private const string PresentJs =
            "(function(){try{return !!(window.AuroraBhumiSidecar&&typeof window.AuroraBhumiSidecar.status==='function')}catch(e){return false}})()";

        // Tombol ✕ pojok kanan atas — jendela pendamping menutupi
        // seluruh layar saat mode login, penutupnya harus di dalam
        // halaman (persis CLOSE_BTN_JS milik BhumiBridge.kt, hanya
        //.NativeBridge.closeWindow → window.chrome.webview.postMessage).
        private const string CloseBtnJs =
            "(function(){function mk(){if(document.getElementById('am-close-bhumi'))return;" +
            "var b=document.createElement('button');b.id='am-close-bhumi';b.type='button';b.textContent='\\u2715';" +
            "b.setAttribute('aria-label','Tutup jendela BHUMI');" +
            "b.style.cssText='position:fixed;top:10px;right:10px;z-index:2147483647;width:40px;height:40px;" +
            "border:0;border-radius:50%;background:rgba(10,10,26,.78);color:#fff;font-size:19px;line-height:40px;" +
            "text-align:center;box-shadow:0 2px 10px rgba(0,0,0,.45);cursor:pointer;';" +
            "b.onclick=function(){try{window.chrome.webview.postMessage('am-close-bhumi');}catch(e){}};" +
            "(document.body||document.documentElement).appendChild(b);}" +
            "if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',mk);}else{mk();}})()";

        private readonly MainForm _ui;
        private WebView2 _wv = null;
        private bool _started = false;
        private volatile bool _pageLoading = true;
        private volatile bool _reloading = false;
        private volatile bool _rebuilding = false;
        private int _miss = 0;
        private string _injectJs = "";
        private System.Windows.Forms.Timer _probeTimer = null;
        private System.Windows.Forms.Timer _tickTimer = null;
        private readonly Dictionary<string, TaskCompletionSource<string>> _pending =
            new Dictionary<string, TaskCompletionSource<string>>(StringComparer.Ordinal);
        private readonly object _pendingLock = new object();
        private string _bhumiProfile;

        internal BhumiSidecar(MainForm ui) { _ui = ui; }

        internal bool Started { get { return _started; } }

        internal async Task<bool> StartAsync(bool showWindow)
        {
            if (_started) return true;
            _started = true;
            _injectJs = BacaInjectJs();

            _bhumiProfile = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "AuroraMaps", "Bhumi");
            try { Directory.CreateDirectory(_bhumiProfile); } catch { /* abaikan */ }

            bool ok = await BuildWebView();
            Program.Log("Pendamping BHUMI " + (ok ? "menyala" : "GAGAL menyala") +
                " — inject " + (_injectJs.Length) + " byte, profil " + _bhumiProfile);

            _probeTimer = new System.Windows.Forms.Timer();
            _probeTimer.Interval = 5000;
            _probeTimer.Tick += (s, e) => ProbeHeal();
            _probeTimer.Start();

            _tickTimer = new System.Windows.Forms.Timer();
            _tickTimer.Interval = 30000;
            _tickTimer.Tick += (s, e) => Tick();
            _tickTimer.Start();

            if (showWindow) ShowWindow();
            return ok;
        }

        // ── Bangun kontrol pendamping (setara buildWebView() via rebuild() Android)
        private async Task<bool> BuildWebView()
        {
            CoreWebView2Environment env = null;
            try
            {
                env = await CoreWebView2Environment.CreateAsync(null, _bhumiProfile, null);
            }
            catch (Exception ex)
            {
                Program.Log("Environment pendamping gagal: " + ex.Message);
                return false;
            }

            var wv = new WebView2();
            _wv = wv;
            _ui.AttachBhumi(wv);
            try
            {
                await wv.EnsureCoreWebView2Async(env);
            }
            catch (Exception ex)
            {
                Program.Log("EnsureCoreWebView2 pendamping gagal: " + ex.Message);
                _ui.DetachBhumi(wv);
                try { wv.Dispose(); } catch { }
                _wv = null;
                return false;
            }

            CoreWebView2 core = wv.CoreWebView2;
            if (!string.IsNullOrEmpty(_injectJs))
                await core.AddScriptToExecuteOnDocumentCreatedAsync(_injectJs); // sebelum navigasi pertama
            await core.AddScriptToExecuteOnDocumentCreatedAsync(CloseBtnJs);

            core.NavigationStarting += (s, e) => { _pageLoading = true; };
            core.NavigationCompleted += (s, e) => { _pageLoading = false; _miss = 0; InjectNow(); };
            core.ProcessFailed += (s, e) =>
            {
                // Port onRenderProcessGone (renderer mati/OOM) — tanpa ini
                // proses app ikut tidak stabil; bangun ulang di tempat.
                var kind = e.ProcessFailedKind;
                bool fatal =
                    kind == CoreWebView2ProcessFailedKind.RenderProcessExited ||
                    kind == CoreWebView2ProcessFailedKind.RenderProcessUnresponsive ||
                    kind == CoreWebView2ProcessFailedKind.BrowserProcessExited;
                if (fatal)
                {
                    Program.Log("Proses pendamping mati (" + kind + ") — dibangun ulang.");
                    RunOnUi(new Action(TryRebuild));
                }
            };
            core.WebMessageReceived += (s, e) =>
            {
                // Dua peran: (1) tombol ✕, (2) balikan deliver() dari
                // Call() — setara NativeBridge.deliver(id, json) Android
                // karena ExecuteScriptAsync TIDAK menunggu Promise
                // (hasil Promise diserialisasi {} tanpa diagunka).
                string asJson = "";
                try { asJson = e.WebMessageAsJson; } catch { asJson = ""; }
                if (asJson.Length > 2 && asJson[0] == '{' &&
                    asJson.Contains("\"r\"") && asJson.Contains("\"id\""))
                {
                    Match mid = Regex.Match(asJson, "\"id\"\\s*:\\s*\"([0-9a-f\\-]{36})\"");
                    if (mid.Success)
                    {
                        TaskCompletionSource<string> tcs = null;
                        lock (_pendingLock)
                        {
                            if (_pending.TryGetValue(mid.Groups[1].Value, out tcs))
                                _pending.Remove(mid.Groups[1].Value);
                        }
                        if (tcs != null)
                        {
                            Match mr = Regex.Match(asJson, "\"r\"\\s*:\\s*(\\{.*\\})\\s*\\}\\s*$",
                                RegexOptions.Singleline);
                            tcs.TrySetResult(mr.Success ? mr.Groups[1].Value : "{}");
                        }
                        return;
                    }
                }
                string msg = "";
                try { msg = e.TryGetWebMessageAsString(); } catch { msg = ""; }
                if (msg == "am-close-bhumi") HideWindow();
            };

            try { core.Navigate(Program.BhumiUrl); }
            catch (Exception exn) { Program.Log("Navigate BHUMI gagal: " + exn.Message); return false; }
            _pageLoading = true;
            return true;
        }

        private async void TryRebuild()
        {
            if (!_started || _rebuilding) return;
            _rebuilding = true;
            FailPending("renderer sidecar mati — sedang dibangun ulang");
            var old = _wv;
            _wv = null;
            if (old != null)
            {
                _ui.DetachBhumi(old);
                try { old.Dispose(); } catch { }
            }
            _miss = 0;
            _pageLoading = true;
            _reloading = false;
            await BuildWebView();
            _rebuilding = false;
        }

        private void FailPending(string alasan)
        {
            lock (_pendingLock)
            {
                foreach (var kv in _pending)
                    kv.Value.TrySetResult("{\"error\":" + JsonQuote(alasan) + "}");
                _pending.Clear();
            }
        }

        // ── API → halaman BHUMI (setara call() milik BhumiBridge.kt) ──
        // Menunggu pada thread PANGGIL (socket worker); eksekusinya
        // dikirim ke UI thread (kewajiban WebView2) via BeginInvoke.
        // Catatan penting: ExecuteScriptAsync TIDAK menunggu Promise
        // (objek Promise diserialisasi {} begitu saja) → sama seperti
        // Android, balidatanya diteruskan lewat
        // window.chrome.webview.postMessage → WebMessageReceived,
        // disandingkan lewat GUID — port NativeBridge.deliver(id, json).
        internal string Call(string method, string arg, int timeoutMs)
        {
            bool dikenal = false;
            for (int i = 0; i < Allowed.Length; i++)
                if (Allowed[i] == method) { dikenal = true; break; }
            if (!dikenal)
                return "{\"error\":\"metode sidecar tidak dikenal: " + JsonQuote(method) + "\"}";

            string id = Guid.NewGuid().ToString("D");
            var tcs = new TaskCompletionSource<string>();
            lock (_pendingLock) _pending[id] = tcs;
            try
            {
                RunOnUi(new Action(async () =>
                {
                    try
                    {
                        var wv = _wv;
                        CoreWebView2 core = wv != null ? wv.CoreWebView2 : null;
                        if (core == null)
                        {
                            Kirim(id, "{\"error\":\"shell sidecar sedang dibangun ulang\"}");
                            return;
                        }
                        string script = BuildScript(id, method, arg);
                        await core.ExecuteScriptAsync(script);
                        // Tidak ada postMessage setelah 3 dtk (umumnya sintaks
                        // diterima tanpa mengeksekusi) → kirim ulang SEKALI;
                        // biaya kecil, pengalih kasus langka yang senyap.
                        await Task.Delay(3000);
                        lock (_pendingLock)
                        {
                            if (_pending.ContainsKey(id)) // belum terbalas
                                try { core.ExecuteScriptAsync(script); } catch { }
                        }
                    }
                    catch (Exception ex)
                    {
                        Kirim(id, "{\"error\":" + JsonQuote(ex.Message) + "}");
                    }
                }));

                if (!tcs.Task.Wait(timeoutMs))
                {
                    lock (_pendingLock) _pending.Remove(id);
                    return "{\"error\":\"timeout sidecar " + timeoutMs + " ms\"}";
                }
                return tcs.Task.Result;
            }
            finally
            {
                lock (_pendingLock) _pending.Remove(id);
            }
        }

        private void Kirim(string id, string json)
        {
            TaskCompletionSource<string> tcs = null;
            lock (_pendingLock)
            {
                if (_pending.TryGetValue(id, out tcs)) _pending.Remove(id);
            }
            if (tcs != null) tcs.TrySetResult(json);
        }

        internal string Status(int timeoutMs)
        {
            return Call("status", "{}", timeoutMs);
        }

        // Susun pemanggilan JS: Promise di-resolve lalu balidatanya
        // dikirim balik sebagai JSON string via postMessage(id, r) —
        // kegagalan selalu menjadi kunci "error" (kontrak 502 server).
        private static string BuildScript(string id, string method, string arg)
        {
            string safeArg = (arg ?? "{}")
                .Replace("\u2028", "\\u2028")
                .Replace("\u2029", "\\u2029");
            return "(function(){var id='" + id + "';" +
                "function kirim(v){try{window.chrome.webview.postMessage({id:id,r:(v===undefined?{}:v)});}catch(e2){}}" +
                "var api=window.AuroraBhumiSidecar;" +
                "if(!api){kirim({sidecar:false,error:'skrip sidecar belum aktif di halaman BHUMI'});return;}" +
                "Promise.resolve(api." + method + "(" + safeArg + "))" +
                ".then(function(r){kirim(r||{});},function(e){kirim({error:String((e&&e.message)||e)});});})();";
        }

        // ── Penjagaan sesi (port tick() Android) ────────────────────
        private void Tick()
        {
            if (!_started || _reloading || _rebuilding) return;
            var wv = _wv;
            CoreWebView2 core = wv != null ? wv.CoreWebView2 : null;
            if (core == null) return;

            string url = "";
            try { url = core.Source; } catch { url = ""; }
            if (string.IsNullOrEmpty(url) ||
                !url.StartsWith(Program.BhumiOrigin, StringComparison.OrdinalIgnoreCase))
            {
                _pageLoading = true;
                try { core.Navigate(Program.BhumiUrl); } catch { }
            }
            // status() memblok (menunggu UI thread) → panggil di thread kerja.
            Task.Run(new Action(TickSession));
        }

        private void TickSession()
        {
            string resp = null;
            try { resp = Status(8000); } catch { resp = null; }
            if (string.IsNullOrEmpty(resp)) return;
            bool loggedIn = false;
            long sisa = -1;
            Match m1 = Regex.Match(resp, @"""loggedIn""\s*:\s*(true|false)");
            if (m1.Success) loggedIn = m1.Groups[1].Value == "true";
            Match m2 = Regex.Match(resp, @"""sisa""\s*:\s*(-?\d+)");
            if (m2.Success) long.TryParse(m2.Groups[1].Value, out sisa);
            if (!loggedIn) { Reload("token basi"); return; }
            if (sisa >= 0 && sisa < MinSisa) Reload("token tinggal " + sisa + " dtk");
        }

        public void Reload(string alasan)
        {
            if (_reloading) return;
            _reloading = true;
            Program.Log("Muat ulang tab BHUMI — " + alasan);
            RunOnUi(new Action(delegate
            {
                var wv = _wv;
                CoreWebView2 core = wv != null ? wv.CoreWebView2 : null;
                if (core != null) try { core.Reload(); } catch { }
            }));
            Task.Run(new Action(delegate
            {
                Thread.Sleep(ReloadLockMs);
                _reloading = false;
            }));
        }

        // ── Penjaga 5 dtk (port probeHeal() Android) ────────────────
        private void ProbeHeal()
        {
            if (!_started || _reloading || _rebuilding || _pageLoading || _injectJs.Length == 0) return;
            RunOnUi(new Action(async () =>
            {
                try
                {
                    var wv = _wv;
                    CoreWebView2 core = wv != null ? wv.CoreWebView2 : null;
                    if (core == null) return;
                    string v = await core.ExecuteScriptAsync(PresentJs);
                    if (v == "true") { _miss = 0; return; }
                    _miss++;
                    InjectNow();
                    if (_miss >= 2) { _miss = 0; Reload("skrip sidecar hilang di halaman"); }
                }
                catch { /* halaman sibuk — telusuri di tick berikutnya */ }
            }));
        }

        private void InjectNow()
        {
            RunOnUi(new Action(delegate
            {
                var wv = _wv;
                CoreWebView2 core = wv != null ? wv.CoreWebView2 : null;
                if (core == null || _injectJs.Length == 0) return;
                try
                {
                    core.ExecuteScriptAsync(_injectJs);
                    core.ExecuteScriptAsync(CloseBtnJs);
                }
                catch { /* abaikan */ }
            }));
        }

        // ── Jendela pendamping ─────────────────────────────────────
        internal void ShowWindow() { RunOnUi(new Action(() => _ui.ShowBhumi())); }
        internal void HideWindow() { RunOnUi(new Action(() => _ui.HideBhumi())); }

        internal void Release()
        {
            if (!_started) return;
            _started = false;
            if (_probeTimer != null) { try { _probeTimer.Stop(); _probeTimer.Dispose(); } catch { } _probeTimer = null; }
            if (_tickTimer != null) { try { _tickTimer.Stop(); _tickTimer.Dispose(); } catch { } _tickTimer = null; }
            FailPending("shell sedang ditutup");
            RunOnUi(new Action(delegate
            {
                var old = _wv;
                _wv = null;
                if (old != null)
                {
                    _ui.DetachBhumi(old);
                    try { old.Dispose(); } catch { }
                }
            }));
        }

        // ── Util ──────────────────────────────────────────────────
        private void RunOnUi(Action a)
        {
            var f = _ui;
            if (f != null && f.IsHandleCreated)
            {
                try { f.BeginInvoke(a); return; }
                catch { /* handle sedang mati — jalankan langsung */ }
            }
            a();
        }

        private static string BacaInjectJs()
        {
            string dir = Program.AppDir;
            string[] kandidat = {
                Path.Combine(dir, "sidecar-inject.js")
            };
            for (int i = 0; i < kandidat.Length; i++)
            {
                try { if (File.Exists(kandidat[i])) return File.ReadAllText(kandidat[i]); }
                catch { /* coba berikutnya */ }
            }
            Program.Log("sidecar-inject.js tidak ditemukan — pendamping tanpa suntik (fitur bidang mati).");
            return "";
        }

        private static string JsonQuote(string s)
        {
            var sb = new StringBuilder();
            sb.Append('"');
            foreach (char ch in s)
            {
                switch (ch)
                {
                    case '\\': sb.Append("\\\\"); break;
                    case '"': sb.Append("\\\""); break;
                    case '\b': sb.Append("\\b"); break;
                    case '\f': sb.Append("\\f"); break;
                    case '\n': sb.Append("\\n"); break;
                    case '\r': sb.Append("\\r"); break;
                    case '\t': sb.Append("\\t"); break;
                    default:
                        if (ch < ' ') sb.Append("\\u").Append(((int)ch).ToString("x4"));
                        else sb.Append(ch);
                        break;
                }
            }
            sb.Append('"');
            return sb.ToString();
        }
    }

    // =====================================================
    // SidecarHttpServer — port langsung SidecarServer.kt
    // =====================================================
    // API loopback 127.0.0.1:8322 memakai TcpListener raw (bukan
    // HttpListener) supaya tidak butuh hak URLACL http.sys —
    // persis ServerSocket(port, 50, 127.0.0.1) milik Android.
    // Rute, whitelist, batas body, dan balasan galat 502 {error}
    // disalin 1:1 → src/js/bhumiSidecar.js bekerja tanpa perubahan.
    // Tambahan CORS: origin GitHub Pages DIDUKUNG (cangkang shell
    // memuat situs) + berkas sidecar-origins.json (blog/domain
    // sendiri) + header Access-Control-Allow-Private-Network untuk
    // preflight PNA Chrome/ggithub dari origin publik ke loopback.
    internal class SidecarHttpServer
    {
        private const int Port = 8322;
        private const int MaxBody = 512 * 1024;
        private const int MaxHeader = 16 * 1024;

        private static readonly string[] TilePaths = {
            "/mprx/service", "/expapi/bhumigeos/umum/wms", "/expapi/bhumigs/umum/wms", "/expapi/umum/wms"
        };
        private const string GistaruHost = "gistaru-app.atrbpn.go.id";
        private const string GeosrvHost = "geosrv-app.atrbpn.go.id";
        private const string BhumiHost = "bhumi.atrbpn.go.id";
        private static readonly string[] SearchPaths = { "/expapi/getBidang", "/expapi/getBidang2" };
        private static readonly string[] BatasPaths = { "/api/propinsi", "/api/kabkot", "/api/kecamatan", "/api/desa", "/api/batas" };
        private const string LokalOriginRegex = @"^http://(localhost|127\.0\.0\.1)(:\d+)?$";

        private readonly BhumiSidecar _bridge;
        private TcpListener _listener = null;
        private volatile bool _running = false;
        private readonly List<string> _origins = new List<string>();

        internal SidecarHttpServer(BhumiSidecar bridge) { _bridge = bridge; }

        internal bool Start()
        {
            if (_running) return true;
            try
            {
                MuatOrigins();
                _listener = new TcpListener(IPAddress.Parse("127.0.0.1"), Port);
                _listener.Start(64);
                _running = true;
                var t = new Thread(new ThreadStart(AcceptLoop));
                t.IsBackground = true;
                t.Start();
                Program.Log("Sidecar 8322 siap (shell, tanpa Node). Origin: " + string.Join(", ", _origins.ToArray()));
                return true;
            }
            catch (Exception e)
            {
                Program.Log("Server 8322 gagal: " + e.Message);
                return false;
            }
        }

        internal void Stop()
        {
            _running = false;
            try { _listener.Stop(); } catch { }
            Program.Log("Server 8322 berhenti.");
        }

        private void AcceptLoop()
        {
            while (_running)
            {
                TcpClient c = null;
                try { c = _listener.AcceptTcpClient(); }
                catch
                {
                    if (!_running) break;
                    Thread.Sleep(200);
                    continue;
                }
                try { c.NoDelay = true; } catch { }
                try { c.Client.ReceiveTimeout = 70000; } catch { }
                try { c.Client.SendTimeout = 30000; } catch { }
                var cc = c;
                Task.Run(new Action(() => Handle(cc)));
            }
        }

        private void Handle(TcpClient cobj)
        {
            try
            {
                using (cobj)
                using (var ns = cobj.GetStream())
                {
                    string raw = ReadHeaders(ns);
                    if (raw.Length == 0) return;
                    string[] lines = raw.Split(new string[] { "\r\n" }, StringSplitOptions.None);
                    string[] parts = lines[0].Split(' ');
                    string method = parts[0].ToUpperInvariant();
                    string path = parts.Length > 1 ? parts[1] : "/";
                    int q = path.IndexOf('?');
                    if (q >= 0) path = path.Substring(0, q);

                    var hdr = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                    for (int i = 1; i < lines.Length; i++)
                    {
                        int idx = lines[i].IndexOf(':');
                        if (idx <= 0) continue;
                        hdr[lines[i].Substring(0, idx).Trim()] = lines[i].Substring(idx + 1).Trim();
                    }

                    int len;
                    string cl;
                    hdr.TryGetValue("content-length", out cl);
                    int.TryParse(cl, out len);
                    if (len < 0) len = 0;
                    if (len > MaxBody) len = MaxBody;
                    byte[] bodyBytes = ReadBody(ns, len);
                    string body = Encoding.UTF8.GetString(bodyBytes);

                    string origin;
                    hdr.TryGetValue("origin", out origin);
                    bool corsOk = IsValidOrigin(origin);
                    bool pna;
                    string pnah;
                    pna = corsOk && hdr.TryGetValue("access-control-request-private-network", out pnah);

                    if (method == "OPTIONS")
                    {
                        WriteHead(ns, 204, "No Content", new byte[0], corsOk, origin, pna);
                        return;
                    }

                    try
                    {
                        if (path == "/status" && (method == "GET" || method == "POST"))
                        {
                            SendResult(ns, _bridge.Status(8000), corsOk, origin, pna);
                        }
                        else if (path == "/search" && method == "POST")
                        {
                            string p = ExtractField(body, "path");
                            if (p == null || Array.IndexOf(SearchPaths, p) < 0)
                                WriteHead(ns, 403, "Forbidden", Utf8("{\"error\":\"Endpoint pencarian ditolak.\"}"), corsOk, origin, pna);
                            else
                                SendResult(ns, _bridge.Call("search", body, 40000), corsOk, origin, pna);
                        }
                        else if (path == "/identify" && method == "POST")
                        {
                            if (!body.Contains("\"body\""))
                                WriteHead(ns, 400, "Bad Request", Utf8("{\"error\":\"Body identify tidak valid.\"}"), corsOk, origin, pna);
                            else
                                SendResult(ns, _bridge.Call("identify", body, 50000), corsOk, origin, pna);
                        }
                        else if (path == "/analisa" && method == "POST")
                        {
                            // Profil Informasi Bidang Tanah — pola identik /identify.
                            if (!body.Contains("\"body\""))
                                WriteHead(ns, 400, "Bad Request", Utf8("{\"error\":\"Body analisa tidak valid.\"}"), corsOk, origin, pna);
                            else
                                SendResult(ns, _bridge.Call("analisa", body, 45000), corsOk, origin, pna);
                        }
                        else if (path == "/tile" && method == "POST")
                        {
                            string u = ExtractField(body, "url");
                            if (!TileAllowed(u))
                                WriteHead(ns, 403, "Forbidden", Utf8("{\"error\":\"URL tile ditolak.\"}"), corsOk, origin, pna);
                            else
                                SendResult(ns, _bridge.Call("tile", body, 15000), corsOk, origin, pna);
                        }
                        else if (path == "/gfi" && method == "POST")
                        {
                            string u = ExtractField(body, "url");
                            if (!GfiAllowed(u))
                                WriteHead(ns, 403, "Forbidden", Utf8("{\"error\":\"URL GFI ditolak.\"}"), corsOk, origin, pna);
                            else
                                SendResult(ns, _bridge.Call("gfi", body, 30000), corsOk, origin, pna);
                        }
                        else if (path == "/proxy" && method == "POST")
                        {
                            string u = ExtractField(body, "url");
                            if (!ProxyAllowed(u))
                                WriteHead(ns, 403, "Forbidden", Utf8("{\"error\":\"URL proxy ditolak.\"}"), corsOk, origin, pna);
                            else
                                SendResult(ns, _bridge.Call("proxy", body, 30000), corsOk, origin, pna);
                        }
                        else if (path == "/proxy-image" && method == "POST")
                        {
                            string u = ExtractField(body, "url");
                            if (!ProxyAllowed(u))
                                WriteHead(ns, 403, "Forbidden", Utf8("{\"error\":\"URL proxy image ditolak.\"}"), corsOk, origin, pna);
                            else
                                SendResult(ns, _bridge.Call("proxyImage", body, 15000), corsOk, origin, pna);
                        }
                        else if (path == "/batas" && method == "POST")
                        {
                            string u = ExtractField(body, "url");
                            if (!BatasAllowed(u))
                                WriteHead(ns, 403, "Forbidden", Utf8("{\"error\":\"URL batas ditolak.\"}"), corsOk, origin, pna);
                            else
                                SendResult(ns, _bridge.Call("batas", body, 30000), corsOk, origin, pna);
                        }
                        else if (path == "/token-sync" && method == "POST")
                        {
                            SendResult(ns, _bridge.Call("tokenSync", body.Trim().Length == 0 ? "{}" : body, 35000), corsOk, origin, pna);
                        }
                        else
                        {
                            WriteHead(ns, 404, "Not Found", Utf8("{\"error\":\"Rute tidak dikenal.\"}"), corsOk, origin, pna);
                        }
                    }
                    catch (Exception e)
                    {
                        WriteHead(ns, 502, "Bad Gateway",
                            Utf8("{\"error\":" + JsonQuote(e.Message ?? e.ToString()) + "}"), corsOk, origin, pna);
                    }
                }
            }
            catch { /* soket mati di tengah — biarkan */ }
        }

        // ── Whitelist (disalin dari SidecarServer.kt) ───────────────
        private static bool TileAllowed(string raw)
        {
            if (string.IsNullOrEmpty(raw)) return false;
            Uri u;
            if (!Uri.TryCreate(raw, UriKind.Absolute, out u)) return false;
            if (u.Scheme != Uri.UriSchemeHttps) return false;
            return (u.Host == BhumiHost && Array.IndexOf(TilePaths, u.AbsolutePath) >= 0) ||
                (u.Host == GistaruHost && u.AbsolutePath.StartsWith("/interoppublic/api/wms/", StringComparison.OrdinalIgnoreCase));
        }

        private static bool GfiAllowed(string raw)
        {
            if (string.IsNullOrEmpty(raw)) return false;
            Uri u;
            if (!Uri.TryCreate(raw, UriKind.Absolute, out u)) return false;
            if (u.Scheme != Uri.UriSchemeHttps) return false;
            return (u.Host == BhumiHost && u.AbsolutePath == "/expapi/rtrw/wms") ||
                (u.Host == GistaruHost && u.AbsolutePath.StartsWith("/interoppublic/api/wms/", StringComparison.OrdinalIgnoreCase));
        }

        private static bool ProxyAllowed(string raw)
        {
            if (string.IsNullOrEmpty(raw)) return false;
            Uri u;
            if (!Uri.TryCreate(raw, UriKind.Absolute, out u)) return false;
            return u.Scheme == Uri.UriSchemeHttps && u.Host == GeosrvHost &&
                u.AbsolutePath == "/geoserver/petabpn/wms";
        }

        private static bool BatasAllowed(string raw)
        {
            if (string.IsNullOrEmpty(raw)) return false;
            Uri u;
            if (!Uri.TryCreate(raw, UriKind.Absolute, out u)) return false;
            return u.Scheme == Uri.UriSchemeHttps && u.Host == BhumiHost &&
                Array.IndexOf(BatasPaths, u.AbsolutePath) >= 0;
        }

        // ── CORS ──────────────────────────────────────────────────
        private void MuatOrigins()
        {
            // 29 Okt 2026: github.io diizinkan (CTA dari versi hosting) —
            // shell menggunakan origin itu sebagai cangkang → prioritas.
            _origins.Clear();
            _origins.Add("https://riacaya.github.io");
            try
            {
                string dir = Program.AppDir;
                string[] kandidat = {
                    Path.Combine(dir, "sidecar-origins.json")
                };
                string isi = null;
                for (int i = 0; i < kandidat.Length; i++)
                {
                    if (File.Exists(kandidat[i])) { isi = File.ReadAllText(kandidat[i]); break; }
                }
                if (isi != null)
                {
                    foreach (Match m in Regex.Matches(isi, "\"((?:[^\"\\\\]|\\\\.)*)\""))
                    {
                        string o = m.Groups[1].Value.Trim().TrimEnd('/');
                        if (o.Length > 0 && Regex.IsMatch(o, @"^https?://") && !_origins.Contains(o))
                            _origins.Add(o);
                    }
                }
            }
            catch (Exception e)
            {
                Program.Log("sidecar-origins.json tidak terbaca (" + e.Message + ") — memakai daftar default.");
            }
        }

        private bool IsValidOrigin(string origin)
        {
            if (string.IsNullOrEmpty(origin)) return false;
            return Regex.IsMatch(origin, LokalOriginRegex) || _origins.Contains(origin);
        }

        // ── Tulis balasan ─────────────────────────────────────────
        private static void SendResult(Stream ns, string json, bool corsOk, string origin, bool pna)
        {
            // Kunci "error" di JSON balasan → 502 (sudut pandang klien = kegagalan).
            bool gagal = Regex.IsMatch(json, "\"error\"\\s*:");
            WriteHead(ns, gagal ? 502 : 200, gagal ? "Bad Gateway" : "OK",
                Utf8(json), corsOk, origin, pna);
        }

        private static void WriteHead(Stream ns, int code, string status, byte[] bytes,
            bool corsOk, string origin, bool pna)
        {
            var h = new StringBuilder();
            h.Append("HTTP/1.1 ").Append(code).Append(' ').Append(status).Append("\r\n");
            h.Append("Content-Type: application/json; charset=utf-8\r\n");
            if (corsOk)
            {
                h.Append("Access-Control-Allow-Origin: ").Append(origin).Append("\r\n");
                h.Append("Vary: Origin\r\n");
                h.Append("Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n");
                h.Append("Access-Control-Allow-Headers: content-type\r\n");
                if (pna) h.Append("Access-Control-Allow-Private-Network: true\r\n");
            }
            h.Append("Connection: close\r\n");
            h.Append("Content-Length: ").Append(bytes.Length).Append("\r\n\r\n");
            byte[] head = Encoding.ASCII.GetBytes(h.ToString());
            ns.Write(head, 0, head.Length);
            if (bytes.Length > 0) ns.Write(bytes, 0, bytes.Length);
            try { ns.Flush(); } catch { }
        }

        private static byte[] Utf8(string s) { return Encoding.UTF8.GetBytes(s); }

        private static string JsonQuote(string s)
        {
            var sb = new StringBuilder();
            sb.Append('"');
            foreach (char ch in s)
            {
                switch (ch)
                {
                    case '\\': sb.Append("\\\\"); break;
                    case '"': sb.Append("\\\""); break;
                    case '\n': sb.Append("\\n"); break;
                    case '\r': sb.Append("\\r"); break;
                    case '\t': sb.Append("\\t"); break;
                    default:
                        if (ch < ' ') sb.Append("\\u").Append(((int)ch).ToString("x4"));
                        else sb.Append(ch);
                        break;
                }
            }
            sb.Append('"');
            return sb.ToString();
        }

        // ── Baca HTTP (port SidecarServer.kt) ──────────────────────
        private static string ExtractField(string json, string name)
        {
            Match m = Regex.Match(json, "\"" + name + "\"\\s*:\\s*\"([^\"]+)\"");
            return m.Success ? m.Groups[1].Value : null;
        }

        private static string ReadHeaders(NetworkStream ns)
        {
            var sb = new StringBuilder();
            while (sb.Length < MaxHeader)
            {
                int b = ns.ReadByte();
                if (b == -1) break;
                sb.Append((char)b);
                int n = sb.Length;
                if (n >= 4 && sb.ToString(n - 4, 4) == "\r\n\r\n") break;
                if (n >= 2 && sb.ToString(n - 2, 2) == "\n\n") break;
            }
            return sb.ToString();
        }

        private static byte[] ReadBody(NetworkStream ns, int len)
        {
            if (len <= 0) return new byte[0];
            var buf = new byte[len];
            int off = 0;
            while (off < len)
            {
                int r = ns.Read(buf, off, len - off);
                if (r <= 0) break;
                off += r;
            }
            return off == len ? buf : (off == 0 ? new byte[0] : (byte[])SmallCopy(buf, off));
        }

        private static byte[] SmallCopy(byte[] buf, int off)
        {
            var r = new byte[off];
            Array.Copy(buf, r, off);
            return r;
        }
    }
}
